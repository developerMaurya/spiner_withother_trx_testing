const mysql = require('mysql2/promise');

const connection = mysql.createPool({
    host: 'localhost',
    user: 'rciclub',
    password: 'rciclub',
    // database: 'games',
    // database: 'colorgame2024'
    database: 'rciclub'
});

export default connection;